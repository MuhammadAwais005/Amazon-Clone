const imgs = document.querySelectorAll('.header-slider img');
const rear_btn = document.querySelector('.rear');
const front_btn = document.querySelector('.front');

let awais = 0; //array size of index

function changes(){
    for (let i = 0; i< imgs.length; i++) {
      imgs[i].style.display = 'none';
       
    }
    imgs[awais].style.display = 'block';
}

changes();

rear_btn.addEventListener('click', (e)=>{

    if(awais > 0){
        awais--;
    }
    else{
        awais = imgs.length - 1;
    }

    changes();
})

front_btn.addEventListener('click', (e)=>{

    if(awais < imgs.length - 1){
        awais++;
    }
    else{
        awais = 0;
    }

    changes();
})